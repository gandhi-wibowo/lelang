-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 28, 2015 at 10:25 AM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cv_witra`
--

-- --------------------------------------------------------

--
-- Table structure for table `iklan`
--

CREATE TABLE IF NOT EXISTS `iklan` (
  `id_iklan` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_admin` int(11) NOT NULL,
  `tgl_iklan` date NOT NULL,
  `file_iklan` varchar(35) NOT NULL,
  `isi_iklan` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_iklan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `id_iklan` int(11) NOT NULL,
  `id_user_lelang` int(11) NOT NULL,
  `isi_komentar` text NOT NULL,
  `waktu_komentar` date NOT NULL,
  `checked` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lelang`
--

CREATE TABLE IF NOT EXISTS `lelang` (
  `id_lelang` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_lelang` int(11) NOT NULL,
  `id_iklan` int(11) NOT NULL,
  `nama_file` varchar(50) NOT NULL,
  `status_menag` enum('0','1') NOT NULL,
  `checked` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_lelang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_admin`
--

CREATE TABLE IF NOT EXISTS `user_admin` (
  `id_user_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(35) NOT NULL,
  `email_admin` varchar(50) NOT NULL,
  `username_admin` varchar(35) NOT NULL,
  `password_admin` varchar(70) NOT NULL,
  PRIMARY KEY (`id_user_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_lelang`
--

CREATE TABLE IF NOT EXISTS `user_lelang` (
  `id_user_lelang` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(35) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `no_rek` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(70) NOT NULL,
  `block` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_user_lelang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
